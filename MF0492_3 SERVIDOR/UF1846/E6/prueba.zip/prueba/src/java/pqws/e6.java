/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pqws;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

/**
 *
 * @author pc
 */
@WebService(serviceName = "e6")
public class e6 {

    /**
     * This is a sample web service operation
     * @param txt
     * @return 
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "suma")
    public String suma(@WebParam(name = "valor1") int valor1, @WebParam(name = "valor2") int valor2) {
        //TODO write your implementation code here:
        return "la suma de los dos numeros  "+valor1 +"+"+valor2+"es:"+(valor1+valor2);
    }
    @WebMethod(operationName = "resta")
    public String resta(@WebParam(name = "valor1") int valor1, @WebParam(name = "valor2") int valor2) {
        //TODO write your implementation code here:
        return "la resta de los dos numeros  "+valor1 +"-"+valor2+"es:"+(valor1-valor2);
    }
    @WebMethod(operationName = "multiplica")
    public String multiplica(@WebParam(name = "valor1") int valor1, @WebParam(name = "valor2") int valor2) {
        //TODO write your implementation code here:
        return "la multiplicacion  de los dos numeros  "+valor1 +"*"+valor2+"es:"+(valor1*valor2);
    }
    @WebMethod(operationName = "divide")
    public String divide(@WebParam(name = "valor1") int valor1, @WebParam(name = "valor2") int valor2) {
        //TODO write your implementation code here:
        return "la division de los dos numeros  "+valor1 +"/"+valor2+"es:"+(valor1/valor2);
    }

    /**
     * Web service operation
     */
   
    
    }
